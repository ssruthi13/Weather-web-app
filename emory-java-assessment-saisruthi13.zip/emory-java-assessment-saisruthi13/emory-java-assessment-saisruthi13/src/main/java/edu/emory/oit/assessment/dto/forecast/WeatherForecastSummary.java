package edu.emory.oit.assessment.dto.forecast;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class WeatherForecastSummary {
    private String latitude;
    private String longitude;
    @JsonProperty("generationtime_ms")
    private double generationTimeMillis;
    @JsonProperty("utc_offset_seconds")
    private double utcOffsetSeconds;
    private String timezone;
    @JsonProperty("timezone_abbreviation")
    private String timezoneAbbreviation;
    private double elevation;
    @JsonProperty("hourly_units")
    private HourlyUnits hourlyUnits;
    private Hourly hourly;
    private LocalDateTime creationTime;
    private LocalDate startDate;
    private LocalDate endDate;
    private List<DayForecastSummary> forecastList;


    public WeatherForecastSummary() {
        this.forecastList = new ArrayList<>();
    }
    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public double getGenerationTimeMillis() {
        return generationTimeMillis;
    }

    public double getUtcOffsetSeconds() {
        return utcOffsetSeconds;
    }

    public String getTimezone() {
        return timezone;
    }

    public String getTimezoneAbbreviation() {
        return timezoneAbbreviation;
    }

    public double getElevation() {
        return elevation;
    }

    public HourlyUnits getHourlyUnits() {
        return hourlyUnits;
    }

    public Hourly getHourly() {
        return hourly;
    }

    public LocalDateTime getCreationTime(){
        return creationTime;
    }

    public LocalDate getStartDate(){
        return startDate;
    }

    public LocalDate getEndDate(){
        return endDate;
    }
    public void addDayForecast(DayForecastSummary dayForecast) {
        forecastList.add(dayForecast);
    }

    public void populateDayForecasts(LocalDate startDate, LocalDate endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.creationTime = LocalDateTime.now();

        if (hourly != null && forecastList != null) {
            int[] precipitationProbabilities = hourly.getPrecipitationProbability();
            int[] relativeHumidity = hourly.getRelativeHumidity();
            double[] windSpeed = hourly.getWindspeed();
            double[] temperatures = hourly.getTemperature();

            if (precipitationProbabilities.length == relativeHumidity.length &&
                    relativeHumidity.length == windSpeed.length &&
                    windSpeed.length == temperatures.length) {
                double sumRelativeHumidity = sumArray(relativeHumidity);
                double sumWindSpeed = sumArray(windSpeed);

                double highestTemperature = findMax(temperatures);
                double lowestTemperature = findMin(temperatures);

                LocalDate currentDate = startDate;
                while (!currentDate.isAfter(endDate)) {
                        DayForecastSummary dayForecast = new DayForecastSummary(
                                currentDate,
                                String.valueOf(highestTemperature),
                                String.valueOf(lowestTemperature),
                                String.valueOf(calculateAverage(precipitationProbabilities, precipitationProbabilities.length)),
                                String.valueOf(calculateAverage(sumRelativeHumidity, relativeHumidity.length)),
                                String.valueOf(calculateAverage(sumWindSpeed, windSpeed.length))
                        );
                        forecastList.add(dayForecast);
                        currentDate = currentDate.plusDays(1);
                }
            }
        }
    }

    public List<DayForecastSummary> getForecasts() {
        List<DayForecastSummary> sortedList = new ArrayList<>(forecastList);

        Collections.sort(sortedList, Comparator.comparing(DayForecastSummary::getDate));

        return sortedList;
    }

    @Override
    public String toString() {
        return "WeatherForecastSummary{" +
                "creationTime='" + creationTime + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate=" + endDate + '\''  +
                ", foreCasts=" + getForecasts()+
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WeatherForecastSummary that = (WeatherForecastSummary) o;
        return Objects.equals(creationTime, that.creationTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(creationTime);
    }
    private double calculateAverage(int[] array, int endIndex) {
        int sum = 0;
        for (int i = 0; i < endIndex; i++) {
            sum += array[i];
        }
        double average = endIndex > 0 ? (double) sum / endIndex : 0;
        return Math.round(average * 10.0) / 10.0;
    }
    private double sumArray(int[] array) {
        int sum = 0;
        for (int value : array) {
            sum += value;
        }
        return sum;
    }

    private double sumArray(double[] array) {
        double sum = 0;
        for (double value : array) {
            sum += value;
        }
        return sum;
    }

    private double calculateAverage(double sum, int count) {
        return count > 0 ? sum / count : 0;
    }

    private double findMax(double[] array) {
        if (array.length == 0) {
            throw new IllegalArgumentException("Array is empty");
        }

        double max = array[0];
        for (double value : array) {
            if (value > max) {
                max = value;
            }
        }
        return max;
    }

    private double findMin(double[] array) {
        if (array.length == 0) {
            throw new IllegalArgumentException("Array is empty");
        }

        double min = array[0];
        for (double value : array) {
            if (value < min) {
                min = value;
            }
        }
        return min;
    }
}
