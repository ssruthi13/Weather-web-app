package edu.emory.oit.assessment.controller;


import edu.emory.oit.assessment.dto.forecast.WeatherForecastSummary;
import edu.emory.oit.assessment.dto.geocode.GeocodeResponse;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;

import java.net.URI;
import java.time.LocalDate;

@CrossOrigin(origins = {"http://localhost:3000"})
@RestController
@RequestMapping("/api/v1")
public class WeatherForecastSummaryController {
    String url = "https://api.open-meteo.com/v1/forecast";
    ///api/v1/weather-summary?postalCode=33135&startDate=2023-06-12&endDate=2023-06-22
    //@CrossOrigin
    @GetMapping("/weather-summary")
    public WeatherForecastSummary getWeatherSummary(
            @RequestParam String postalCode,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate){
        WebClient.Builder builder = WebClient.builder();
        URI geoCodeUrl = URI.create(String.format("https://api.zippopotam.us/us/%s", postalCode));
        GeocodeResponse geocodeResponse = builder.build()
                .get()
                .uri(geoCodeUrl)
                .retrieve()
                .bodyToMono(GeocodeResponse.class)
                .block();

        String latitude = geocodeResponse.getPlaces()[0].getLatitude();
        String longitude = geocodeResponse.getPlaces()[0].getLongitude();
        System.out.println(latitude + ", " + longitude);

        URI apiUrl = URI.create(String.format("%s?latitude=%s&longitude=%s&start_date=%s&end_date=%s&hourly=temperature_2m,precipitation_probability,relativehumidity_2m,windspeed_10m&temperature_unit=fahrenheit&windspeed_unit=mph", url, latitude,longitude, startDate, endDate));
        WeatherForecastSummary weatherForecastSummary =  builder.build()
                .get()
                .uri(apiUrl)
                .retrieve()
                .bodyToMono(WeatherForecastSummary.class)
                .block();
        weatherForecastSummary.populateDayForecasts(startDate, endDate);
        System.out.println(weatherForecastSummary.toString());
        return weatherForecastSummary;
    }
}
