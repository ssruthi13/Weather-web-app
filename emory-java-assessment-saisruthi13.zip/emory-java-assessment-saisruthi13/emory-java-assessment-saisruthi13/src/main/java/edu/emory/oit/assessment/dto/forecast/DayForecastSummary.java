package edu.emory.oit.assessment.dto.forecast;

import java.time.LocalDate;

public class DayForecastSummary {
    private LocalDate date;
    private String highestTemperature;
    private String lowestTemperature;
    private String averagePrecipitationProbability;
    private String averageRelativeHumidity;
    private String averageWindSpeed;

    public DayForecastSummary(LocalDate date, String highestTemperature, String lowestTemperature,
                              String averagePrecipitationProbability, String averageRelativeHumidity,
                              String averageWindSpeed) {
        this.date = date;
        this.highestTemperature = highestTemperature;
        this.lowestTemperature = lowestTemperature;
        this.averagePrecipitationProbability = averagePrecipitationProbability;
        this.averageRelativeHumidity = averageRelativeHumidity;
        this.averageWindSpeed = averageWindSpeed;
    }
    public String getHighestTemperature() {
        return highestTemperature;
    }
    public String getLowestTemperature() {
        return lowestTemperature;
    }
    public String getAveragePrecipitationProbability() {
        return averagePrecipitationProbability;
    }
    public String getAverageRelativeHumidity() {
        return averageRelativeHumidity;
    }
    public String getAverageWindSpeed() {
        return averageWindSpeed;
    }
    public LocalDate getDate() {
        return date;
    }
    @Override
    public String toString() {
        return "DayForecastSummary{" +
                "date='" + date + '\'' +
                ", highestTemperature='" + highestTemperature + '\'' +
                ", lowestTemperature='" + lowestTemperature + '\'' +
                ", averagePrecipitationProbability='" + averagePrecipitationProbability + '\'' +
                ", averageRelativeHumidity='" + averageRelativeHumidity + '\'' +
                ", averageWindSpeed='" + averageWindSpeed + '\'' +
                '}';
    }
}

