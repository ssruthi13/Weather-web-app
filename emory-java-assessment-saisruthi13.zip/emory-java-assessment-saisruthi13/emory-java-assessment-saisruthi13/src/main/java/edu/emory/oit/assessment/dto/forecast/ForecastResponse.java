package edu.emory.oit.assessment.dto.forecast;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ForecastResponse {
  private String latitude;
  private String longitude;
  @JsonProperty("generationtime_ms")
  private double generationTimeMillis;
  @JsonProperty("utc_offset_seconds")
  private double utcOffsetSeconds;
  private String timezone;
  @JsonProperty("timezone_abbreviation")
  private String timezoneAbbreviation;
  private double elevation;
  @JsonProperty("hourly_units")
  private HourlyUnits hourlyUnits;
  private Hourly hourly;

  public String getLatitude() {
    return latitude;
  }

  public String getLongitude() {
    return longitude;
  }

  public double getGenerationTimeMillis() {
    return generationTimeMillis;
  }

  public double getUtcOffsetSeconds() {
    return utcOffsetSeconds;
  }

  public String getTimezone() {
    return timezone;
  }

  public String getTimezoneAbbreviation() {
    return timezoneAbbreviation;
  }

  public double getElevation() {
    return elevation;
  }

  public HourlyUnits getHourlyUnits() {
    return hourlyUnits;
  }

  public Hourly getHourly() {
    return hourly;
  }

  @Override
  public String toString() {
    return "ForecastResponse{" +
        "latitude='" + latitude + '\'' +
        ", longitude='" + longitude + '\'' +
        ", generationTimeMillis=" + generationTimeMillis +
        ", utcOffsetSeconds=" + utcOffsetSeconds +
        ", timezone='" + timezone + '\'' +
        ", timezoneAbbreviation='" + timezoneAbbreviation + '\'' +
        ", elevation=" + elevation +
        ", hourlyUnits=" + hourlyUnits +
        ", hourly=" + hourly +
        '}';
  }
}
