package edu.emory.oit.assessment.controller;

import static org.junit.jupiter.api.Assertions.*;

class WeatherForecastSummaryControllerTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.Test
    void getWeatherSummary() {
    }
}