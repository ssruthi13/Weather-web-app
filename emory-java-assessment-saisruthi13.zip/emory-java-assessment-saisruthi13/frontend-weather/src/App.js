import { useState } from 'react'
import {
  MDBCardBody,
  MDBCol,
  MDBRow,
} from "mdb-react-ui-kit";

function App() {
  const [searchInput, setSearchInput] = useState({
    postalCode: '',
    startDate: '',
    endDate: '',
  });
  const [weather, setWeather] = useState({});
  const api = "http://localhost:8080/api/v1";
  const search = async (event) => {
    event.preventDefault();      
      try {
        const response = await fetch(`${api}/weather-summary?postalCode=${searchInput.postalCode}&startDate=${searchInput.startDate}&endDate=${searchInput.endDate}`);
        
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
    
        const parsedData = await response.json();
        setWeather({
          forecasts: parsedData.forecasts.map(forecast => ({
            date: forecast.date,
            highestTemperature: `${forecast.highestTemperature}°F`,
            lowestTemperature: `${forecast.lowestTemperature}°F`,
            averagePrecipitationProbability: `${forecast.averagePrecipitationProbability}%`,
            averageRelativeHumidity: `${forecast.averageRelativeHumidity}%`,
            averageWindspeed: `${forecast.averageWindSpeed}mp/h`
          }))
        });
        setSearchInput({
          postalCode: '',
          startDate: '',
          endDate: '',
        });
      } catch (error) {
        console.error('Error fetching data:', error);
      }
  }
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSearchInput({
      ...searchInput,
      [name]: value,
    });
  };
  return (
    <div className={typeof weather.main != "undefined" ? ((weather.main.temp>16) ? 'app warm' : 'app') : 'app'}>
      <main>
      <form onSubmit={search}>
  <div className="search-box">
    <input
      type="text"
      name="postalCode"
      className='search-bar'
      placeholder='Postal Code'
      value={searchInput.postalCode}
      onChange={handleInputChange}
      required
    />
    <input
      type="date"
      name="startDate"
      className='search-bar'
      placeholder='Start Date'
      value={searchInput.startDate}
      onChange={handleInputChange}
      required
    />
    <input
      type="date"
      name="endDate"
      className='search-bar'
      placeholder='End Date'
      value={searchInput.endDate}
      onChange={handleInputChange}
      required
    />
    <button type="submit">Search</button>
  </div>
</form>

{typeof weather.forecasts !== 'undefined' && weather.forecasts.length > 0 ? (
  <div>
    {weather.forecasts.map((forecast, index) => (
      <MDBCardBody className="forecast-box" key={index}>
        <MDBRow className="text-center">
          <MDBCol size="2">
            <strong className="date">Date<br/><br/></strong>
            <strong className="d-block">{forecast.date}</strong>
          </MDBCol>
          <MDBCol size="2">
            <strong className="temperature">Highest Temp</strong>
            <strong className="d-block">{forecast.highestTemperature}</strong>
          </MDBCol>
          <MDBCol size="2">
            <strong className="d-block mb-2">Lowest Temp</strong>
            <strong className="d-block">{forecast.lowestTemperature}</strong>
          </MDBCol>
          <MDBCol size="2">
            <strong className="d-block mb-2">Precip Prob</strong>
            <strong className="d-block">{forecast.averagePrecipitationProbability}</strong>
          </MDBCol>
          <MDBCol size="2">
            <strong className="d-block mb-2">Relative Humidity</strong>
            <strong className="d-block">{forecast.averageRelativeHumidity}</strong>
          </MDBCol>
          <MDBCol size="2">
            <strong className="d-block mb-2">Wind Speed</strong>
            <strong className="d-block">{forecast.averageWindSpeed}</strong>
          </MDBCol>
        </MDBRow>
      </MDBCardBody>
    ))}
  </div>
) : (
  <div className="weather-box">
    <div className="weather" style={{ fontSize: "30px" }}>
      Get Your <br /> Weather Forecast
    </div>
  </div>
)}
</main>
    </div>
  )
}

export default App;